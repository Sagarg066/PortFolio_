// Portfolio data
const portfolioData = {
  "personalInfo": {
    "name": "Alex Johnson",
    "title": "Full Stack Developer & UI/UX Designer",
    "tagline": "Creating digital experiences that make a difference",
    "email": "alex.johnson@email.com",
    "phone": "+1 (555) 123-4567",
    "location": "San Francisco, CA",
    "bio": "I'm a passionate full-stack developer and UI/UX designer with 5+ years of experience creating innovative digital solutions. I combine technical expertise with creative design thinking to build applications that not only function flawlessly but also provide exceptional user experiences. My approach focuses on understanding user needs, solving complex problems, and delivering high-quality results that drive business success."
  },
  "skills": {
    "technical": [
      {"name": "JavaScript", "level": 90, "category": "Frontend"},
      {"name": "React", "level": 85, "category": "Frontend"},
      {"name": "Node.js", "level": 80, "category": "Backend"},
      {"name": "Python", "level": 75, "category": "Backend"},
      {"name": "TypeScript", "level": 85, "category": "Frontend"},
      {"name": "MongoDB", "level": 70, "category": "Database"},
      {"name": "PostgreSQL", "level": 75, "category": "Database"},
      {"name": "AWS", "level": 70, "category": "Cloud"}
    ],
    "design": [
      {"name": "Figma", "level": 85, "category": "Design"},
      {"name": "Adobe XD", "level": 80, "category": "Design"},
      {"name": "Photoshop", "level": 75, "category": "Design"},
      {"name": "UI/UX Design", "level": 90, "category": "Design"},
      {"name": "Prototyping", "level": 85, "category": "Design"},
      {"name": "Wireframing", "level": 88, "category": "Design"}
    ],
    "soft": [
      {"name": "Problem Solving", "level": 95},
      {"name": "Communication", "level": 90},
      {"name": "Team Leadership", "level": 85},
      {"name": "Project Management", "level": 80},
      {"name": "Creative Thinking", "level": 92}
    ]
  },
  "experience": [
    {
      "company": "TechCorp Solutions",
      "position": "Senior Full Stack Developer",
      "duration": "2022 - Present",
      "description": "Lead development of enterprise web applications serving 100K+ users. Architected scalable microservices and mentored junior developers.",
      "achievements": [
        "Improved application performance by 40%",
        "Led team of 6 developers",
        "Implemented CI/CD pipeline reducing deployment time by 60%"
      ],
      "technologies": ["React", "Node.js", "AWS", "MongoDB", "Docker"]
    },
    {
      "company": "StartupXYZ",
      "position": "Full Stack Developer",
      "duration": "2020 - 2022",
      "description": "Developed MVP for fintech startup from concept to launch. Built responsive web app and mobile-first design system.",
      "achievements": [
        "Launched product to 10K+ users in first month",
        "Designed complete user interface",
        "Integrated payment processing systems"
      ],
      "technologies": ["Vue.js", "Express.js", "PostgreSQL", "Stripe API"]
    },
    {
      "company": "Design Agency Pro",
      "position": "UI/UX Designer & Frontend Developer",
      "duration": "2019 - 2020",
      "description": "Created digital experiences for diverse clients ranging from e-commerce to SaaS platforms.",
      "achievements": [
        "Delivered 25+ client projects",
        "Increased client conversion rates by average 35%",
        "Established design system standards"
      ],
      "technologies": ["React", "Figma", "JavaScript", "SASS"]
    }
  ],
  "projects": [
    {
      "title": "E-Commerce Platform",
      "description": "Full-stack e-commerce solution with inventory management, payment processing, and admin dashboard.",
      "category": "Web Development",
      "technologies": ["React", "Node.js", "MongoDB", "Stripe", "AWS"],
      "features": ["User authentication", "Payment processing", "Inventory management", "Order tracking"],
      "githubUrl": "https://github.com/username/ecommerce-platform",
      "liveUrl": "https://ecommerce-demo.com",
      "image": "https://via.placeholder.com/400x250/4A90E2/FFFFFF?text=E-Commerce+Platform"
    },
    {
      "title": "Task Management App",
      "description": "Collaborative task management application with real-time updates and team collaboration features.",
      "category": "Web Development",
      "technologies": ["Vue.js", "Express.js", "Socket.io", "PostgreSQL"],
      "features": ["Real-time collaboration", "Task assignment", "Progress tracking", "Team chat"],
      "githubUrl": "https://github.com/username/task-manager",
      "liveUrl": "https://taskmanager-demo.com",
      "image": "https://via.placeholder.com/400x250/50C878/FFFFFF?text=Task+Manager"
    },
    {
      "title": "Weather Dashboard",
      "description": "Responsive weather application with location-based forecasts and interactive data visualizations.",
      "category": "Web Development",
      "technologies": ["JavaScript", "Chart.js", "Weather API", "CSS3"],
      "features": ["Location detection", "7-day forecast", "Interactive charts", "Weather alerts"],
      "githubUrl": "https://github.com/username/weather-dashboard",
      "liveUrl": "https://weather-demo.com",
      "image": "https://via.placeholder.com/400x250/FFA500/FFFFFF?text=Weather+Dashboard"
    },
    {
      "title": "Healthcare Mobile App",
      "description": "Mobile-first healthcare application for appointment booking and patient management.",
      "category": "Mobile Apps",
      "technologies": ["React Native", "Firebase", "Node.js", "MongoDB"],
      "features": ["Appointment booking", "Patient records", "Push notifications", "Telemedicine"],
      "githubUrl": "https://github.com/username/healthcare-app",
      "liveUrl": "https://healthcare-demo.com",
      "image": "https://via.placeholder.com/400x250/9370DB/FFFFFF?text=Healthcare+App"
    },
    {
      "title": "SaaS Dashboard Design",
      "description": "Complete UI/UX design system for B2B SaaS analytics dashboard with dark and light themes.",
      "category": "UI/UX Design",
      "technologies": ["Figma", "Adobe XD", "Principle", "InVision"],
      "features": ["Design system", "Responsive layout", "Data visualization", "User testing"],
      "githubUrl": "https://github.com/username/saas-design",
      "liveUrl": "https://saas-design-demo.com",
      "image": "https://via.placeholder.com/400x250/FF6B6B/FFFFFF?text=SaaS+Dashboard"
    },
    {
      "title": "Banking App Redesign",
      "description": "Mobile banking application redesign focusing on accessibility and user experience improvements.",
      "category": "UI/UX Design",
      "technologies": ["Sketch", "Figma", "Marvel", "Usability Testing"],
      "features": ["Accessibility compliance", "User research", "Prototype testing", "Design handoff"],
      "githubUrl": "https://github.com/username/banking-redesign",
      "liveUrl": "https://banking-redesign-demo.com",
      "image": "https://via.placeholder.com/400x250/4ECDC4/FFFFFF?text=Banking+Redesign"
    }
  ],
  "goals": {
    "shortTerm": [
      "Master advanced React patterns and state management",
      "Contribute to open-source projects",
      "Obtain AWS Solutions Architect certification",
      "Lead a major product launch"
    ],
    "longTerm": [
      "Become a technical lead or engineering manager",
      "Start my own tech consultancy",
      "Mentor junior developers and designers",
      "Build products that positively impact communities"
    ],
    "mission": "To create technology solutions that solve real-world problems while fostering inclusive and collaborative development environments.",
    "seeking": "I'm looking for opportunities to work with innovative teams on challenging projects that push the boundaries of web technology and user experience. I'm particularly interested in roles that combine technical leadership with creative problem-solving in growth-stage companies or impactful startups."
  },
  "testimonials": [
    {
      "name": "Sarah Mitchell",
      "position": "Product Manager",
      "company": "TechCorp Solutions",
      "rating": 5,
      "text": "Alex is an exceptional developer who consistently delivers high-quality solutions. Their ability to bridge the gap between technical requirements and user experience is remarkable.",
      "image": "https://via.placeholder.com/80x80/FF9500/FFFFFF?text=SM"
    },
    {
      "name": "Michael Chen",
      "position": "CTO",
      "company": "StartupXYZ",
      "rating": 5,
      "text": "Working with Alex was a game-changer for our startup. They built our entire platform from scratch and helped us scale to thousands of users seamlessly.",
      "image": "https://via.placeholder.com/80x80/007AFF/FFFFFF?text=MC"
    },
    {
      "name": "Emma Rodriguez",
      "position": "Design Director",
      "company": "Design Agency Pro",
      "rating": 5,
      "text": "Alex has a unique talent for translating complex design concepts into functional, beautiful interfaces. Their attention to detail and user-centric approach is outstanding.",
      "image": "https://via.placeholder.com/80x80/34C759/FFFFFF?text=ER"
    }
  ]
};

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeHeroButtons();
    initializeSkills();
    initializeExperience();
    initializePortfolio();
    initializeGoals();
    initializeTestimonials();
    initializeContactForm();
    initializeScrollEffects();
    initializeModal();
});

// Navigation functionality
function initializeNavigation() {
    const nav = document.getElementById('nav');
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.getElementById('nav-menu');

    // Mobile menu toggle
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            navToggle.classList.toggle('active');
        });
    }

    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav__link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const offsetTop = targetElement.offsetTop - 80; // Account for fixed nav
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }

            // Close mobile menu
            if (navMenu && navToggle) {
                navMenu.classList.remove('active');
                navToggle.classList.remove('active');
            }
        });
    });

    // Update active navigation link on scroll
    window.addEventListener('scroll', updateActiveNavLink);
}

// Hero section buttons
function initializeHeroButtons() {
    // View My Work button
    const viewWorkBtn = document.querySelector('.hero__buttons .btn--primary');
    if (viewWorkBtn) {
        viewWorkBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const portfolioSection = document.getElementById('portfolio');
            if (portfolioSection) {
                const offsetTop = portfolioSection.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    }

    // Download Resume button - create a dummy PDF download
    const downloadResumeBtn = document.querySelector('.hero__buttons .btn--outline');
    if (downloadResumeBtn) {
        downloadResumeBtn.addEventListener('click', (e) => {
            e.preventDefault();
            // Simulate PDF download
            const link = document.createElement('a');
            link.href = 'data:application/pdf;base64,JVBERi0xLjQKMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovUGFnZXMgMiAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL1R5cGUgL1BhZ2VzCi9LaWRzIFsgMyAwIFIgXQovQ291bnQgMQo+PgplbmRvYmoKMyAwIG9iago8PAovVHlwZSAvUGFnZQovUGFyZW50IDIgMCBSCi9NZWRpYUJveCBbIDAgMCA2MTIgNzkyIF0KL1Jlc291cmNlcyA8PAovRm9udCA0IDAgUgo+PgovQ29udGVudHMgNSAwIFIKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0YxIDYgMCBSCj4+CmVuZG9iago1IDAgb2JqCjw8Ci9MZW5ndGggNDQKPj4Kc3RyZWFtCkJUCi9GMSAxMiBUZgowIDAgVGQKKEFsZXggSm9obnNvbiAtIFJlc3VtZSkgVGoKRVQKZW5kc3RyZWFtCmVuZG9iago2IDAgb2JqCjw8Ci9UeXBlIC9Gb250Ci9CYXNlRm9udCAvSGVsdmV0aWNhCi9TdWJ0eXBlIC9UeXBlMQo+PgplbmRvYmoKeHJlZgo0NTEKLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLQp0cmFpbGVyCjw8Ci9TaXplIDcKL1Jvb3QgMSAwIFIKPj4Kc3RhcnR4cmVmCjU0NAolJUVPRgo=';
            link.download = 'Alex_Johnson_Resume.pdf';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            // Show feedback
            const originalText = downloadResumeBtn.textContent;
            downloadResumeBtn.textContent = 'Downloaded!';
            setTimeout(() => {
                downloadResumeBtn.textContent = originalText;
            }, 2000);
        });
    }
}

function updateActiveNavLink() {
    const sections = document.querySelectorAll('section[id]');
    const scrollY = window.scrollY + 100;

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        const sectionId = section.getAttribute('id');

        if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
            document.querySelectorAll('.nav__link').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${sectionId}`) {
                    link.classList.add('active');
                }
            });
        }
    });
}

// Skills section
function initializeSkills() {
    renderSkills('technical-skills', portfolioData.skills.technical);
    renderSkills('design-skills', portfolioData.skills.design);
    renderSkills('soft-skills', portfolioData.skills.soft);

    // Animate skill bars when section comes into view
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateSkillBars();
            }
        });
    }, { threshold: 0.3 });

    const skillsSection = document.getElementById('skills');
    if (skillsSection) {
        observer.observe(skillsSection);
    }
}

function renderSkills(containerId, skills) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = skills.map(skill => `
        <div class="skill-item">
            <h4>
                ${skill.name}
                <span class="skill-level">${skill.level}%</span>
            </h4>
            <div class="skill-bar">
                <div class="skill-progress" data-level="${skill.level}"></div>
            </div>
        </div>
    `).join('');
}

function animateSkillBars() {
    const progressBars = document.querySelectorAll('.skill-progress');
    progressBars.forEach(bar => {
        const level = bar.getAttribute('data-level');
        setTimeout(() => {
            bar.style.width = `${level}%`;
        }, 100);
    });
}

// Experience section
function initializeExperience() {
    const timeline = document.getElementById('experience-timeline');
    if (!timeline) return;

    timeline.innerHTML = portfolioData.experience.map(job => `
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h3 class="job-title">${job.position}</h3>
                <h4 class="company-name">${job.company}</h4>
                <p class="job-duration">${job.duration}</p>
                <p class="job-description">${job.description}</p>
                <ul class="achievements">
                    ${job.achievements.map(achievement => `<li>${achievement}</li>`).join('')}
                </ul>
                <div class="tech-tags">
                    ${job.technologies.map(tech => `<span class="tech-tag">${tech}</span>`).join('')}
                </div>
            </div>
        </div>
    `).join('');
}

// Portfolio section
function initializePortfolio() {
    renderPortfolio(portfolioData.projects);
    initializePortfolioFilters();
}

function renderPortfolio(projects) {
    const grid = document.getElementById('portfolio-grid');
    if (!grid) return;

    grid.innerHTML = projects.map(project => `
        <div class="project-card" data-category="${project.category}" data-project='${JSON.stringify(project)}'>
            <div class="project-image" style="background-image: url('${project.image}')"></div>
            <div class="project-content">
                <h3 class="project-title">${project.title}</h3>
                <p class="project-description">${project.description}</p>
                <div class="project-tech">
                    ${project.technologies.map(tech => `<span class="tech-tag">${tech}</span>`).join('')}
                </div>
                <div class="project-links">
                    <a href="${project.liveUrl}" target="_blank" class="project-link" onclick="event.stopPropagation()">Live Demo</a>
                    <a href="${project.githubUrl}" target="_blank" class="project-link" onclick="event.stopPropagation()">GitHub</a>
                </div>
            </div>
        </div>
    `).join('');

    // Add click listeners for project cards
    const projectCards = document.querySelectorAll('.project-card');
    projectCards.forEach(card => {
        card.addEventListener('click', (e) => {
            // Don't open modal if clicking on links
            if (e.target.classList.contains('project-link') || e.target.closest('.project-link')) return;
            
            const projectData = JSON.parse(card.getAttribute('data-project'));
            openProjectModal(projectData);
        });
    });
}

function initializePortfolioFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const filter = button.getAttribute('data-filter');
            
            // Update active filter button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            // Filter projects
            const projectCards = document.querySelectorAll('.project-card');
            projectCards.forEach(card => {
                const cardCategory = card.getAttribute('data-category');
                if (filter === 'all' || cardCategory === filter) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

// Modal functionality
function initializeModal() {
    const modal = document.getElementById('project-modal');
    const modalOverlay = document.getElementById('modal-overlay');
    const modalClose = document.getElementById('modal-close');

    if (modalOverlay) {
        modalOverlay.addEventListener('click', closeModal);
    }
    
    if (modalClose) {
        modalClose.addEventListener('click', closeModal);
    }
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeModal();
    });
}

function openProjectModal(project) {
    const modal = document.getElementById('project-modal');
    const modalBody = document.getElementById('modal-body');
    
    if (!modal || !modalBody) return;

    modalBody.innerHTML = `
        <div style="background-image: url('${project.image}'); height: 300px; background-size: cover; background-position: center; border-radius: 8px; margin-bottom: 24px;"></div>
        <h2 style="margin-bottom: 16px; color: var(--color-primary);">${project.title}</h2>
        <p style="margin-bottom: 24px; font-size: 18px; line-height: 1.6;">${project.description}</p>
        
        <h3 style="margin-bottom: 12px; color: var(--color-primary);">Key Features</h3>
        <ul style="margin-bottom: 24px;">
            ${project.features.map(feature => `<li style="margin-bottom: 8px;">${feature}</li>`).join('')}
        </ul>
        
        <h3 style="margin-bottom: 12px; color: var(--color-primary);">Technologies Used</h3>
        <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 24px;">
            ${project.technologies.map(tech => `<span class="tech-tag">${tech}</span>`).join('')}
        </div>
        
        <div style="display: flex; gap: 16px; justify-content: center;">
            <a href="${project.liveUrl}" target="_blank" class="btn btn--primary">View Live Demo</a>
            <a href="${project.githubUrl}" target="_blank" class="btn btn--outline">View Code</a>
        </div>
    `;
    
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    const modal = document.getElementById('project-modal');
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto';
    }
}

// Goals section
function initializeGoals() {
    const shortTermList = document.getElementById('short-term-goals');
    const longTermList = document.getElementById('long-term-goals');

    if (shortTermList) {
        shortTermList.innerHTML = portfolioData.goals.shortTerm.map(goal => `<li>${goal}</li>`).join('');
    }

    if (longTermList) {
        longTermList.innerHTML = portfolioData.goals.longTerm.map(goal => `<li>${goal}</li>`).join('');
    }
}

// Testimonials section
function initializeTestimonials() {
    const grid = document.getElementById('testimonials-grid');
    if (!grid) return;

    grid.innerHTML = portfolioData.testimonials.map(testimonial => `
        <div class="testimonial-card">
            <div class="testimonial-header">
                <div class="testimonial-avatar" style="background-image: url('${testimonial.image}')"></div>
                <div class="testimonial-info">
                    <h4>${testimonial.name}</h4>
                    <p>${testimonial.position} at ${testimonial.company}</p>
                </div>
            </div>
            <div class="testimonial-rating">
                ${Array.from({length: testimonial.rating}, () => '<span class="star">★</span>').join('')}
            </div>
            <p class="testimonial-text">"${testimonial.text}"</p>
        </div>
    `).join('');
}

// Contact form
function initializeContactForm() {
    const form = document.getElementById('contact-form');
    if (!form) return;

    form.addEventListener('submit', handleContactSubmit);

    // Real-time validation
    const inputs = form.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        input.addEventListener('blur', () => validateField(input));
        input.addEventListener('input', () => clearError(input));
    });
}

function handleContactSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    
    // Validate all fields
    let isValid = true;
    const requiredFields = ['name', 'email', 'subject', 'message'];
    
    requiredFields.forEach(field => {
        const input = document.getElementById(field);
        if (!validateField(input)) {
            isValid = false;
        }
    });

    if (isValid) {
        // Simulate form submission
        const submitButton = e.target.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        
        submitButton.textContent = 'Sending...';
        submitButton.disabled = true;
        
        setTimeout(() => {
            submitButton.textContent = 'Message Sent!';
            submitButton.style.background = 'var(--color-success)';
            
            setTimeout(() => {
                submitButton.textContent = originalText;
                submitButton.disabled = false;
                submitButton.style.background = '';
                e.target.reset();
                
                // Clear all error messages
                const errorElements = document.querySelectorAll('.error-message');
                errorElements.forEach(el => el.textContent = '');
            }, 2000);
        }, 1500);
    }
}

function validateField(input) {
    const value = input.value.trim();
    const errorElement = document.getElementById(`${input.name}-error`);
    let isValid = true;
    let errorMessage = '';

    if (!value) {
        errorMessage = `${input.name.charAt(0).toUpperCase() + input.name.slice(1)} is required`;
        isValid = false;
    } else if (input.type === 'email' && !isValidEmail(value)) {
        errorMessage = 'Please enter a valid email address';
        isValid = false;
    }

    if (errorElement) {
        errorElement.textContent = errorMessage;
    }

    input.classList.toggle('error', !isValid);
    return isValid;
}

function clearError(input) {
    const errorElement = document.getElementById(`${input.name}-error`);
    if (errorElement) {
        errorElement.textContent = '';
    }
    input.classList.remove('error');
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Scroll effects
function initializeScrollEffects() {
    window.addEventListener('scroll', () => {
        handleNavbarScroll();
        handleBackToTopButton();
    });

    // Back to top button
    const backToTopBtn = document.getElementById('back-to-top');
    if (backToTopBtn) {
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

function handleNavbarScroll() {
    const nav = document.getElementById('nav');
    if (nav) {
        if (window.scrollY > 100) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }
    }
}

function handleBackToTopButton() {
    const backToTopBtn = document.getElementById('back-to-top');
    if (backToTopBtn) {
        if (window.scrollY > 500) {
            backToTopBtn.classList.add('visible');
        } else {
            backToTopBtn.classList.remove('visible');
        }
    }
}